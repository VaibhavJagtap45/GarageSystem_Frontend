import React from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  StatusBar,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import TopNav from "../../components/ui/TopNav";
import { COLORS, FONTS, SIZES } from "../../utils/constants";

// ─── Content ──────────────────────────────────────────────────────────────────
const SECTIONS = [
  {
    title: "OVERVIEW",
    body: `This website / Mobile Application is operated by Albos Pvt. Ltd. Throughout the site, the terms "we", "us" and "our" refer to Albos Pvt Ltd. Albos Pvt Ltd offers this website, including all information, tools and services available from this site to you, the user, conditioned upon your acceptance of all terms, conditions, policies and notices stated here.

By visiting our site and/or purchasing something from us, you engage in our "Service" and agree to be bound by the following terms and conditions ("Terms of Service", "Terms"), including those additional terms and conditions and policies referenced herein and/or available by hyperlink. These Terms of Service apply to all users of the site, including without limitation users who are browsers, vendors, customers, merchants, and/or contributors of content.

Please read these Terms of Service carefully before accessing or using our website/mobile application. By accessing or using any part of the site, you agree to be bound by these Terms of Service. If you do not agree to all the terms and conditions of this agreement, then you may not access the website or use any services.

Any new features or tools which are added to the current website/mobile application shall also be subject to the Terms of Service. You can review the most current version of the Terms of Service at any time on this page. We reserve the right to update, change or replace any part of these Terms of Service by posting updates and/or changes to our website.`,
  },
  {
    title: "SECTION 1 – ApnoGarage USAGE TERMS",
    body: `By agreeing to these Terms of Service, you represent that you are at least the age of majority in your state or province of residence, or that you are the age of majority in your state or province of residence and you have given us your consent to allow any of your minor dependents to use this site.

You may not use our products for any illegal or unauthorized purpose nor may you, in the use of the Service, violate any laws in your jurisdiction (including but not limited to copyright laws).

You must not transmit any worms or viruses or any code of a destructive nature.

A breach or violation of any of the Terms will result in an immediate termination of your Services.`,
  },
  {
    title: "SECTION 2 – GENERAL CONDITIONS",
    body: `We reserve the right to refuse service to anyone for any reason at any time.

You understand that your content (not including credit card information), may be transferred unencrypted and involve (a) transmissions over various networks; and (b) changes to conform and adapt to technical requirements of connecting networks or devices. Credit card information is always encrypted during transfer over networks.

You agree not to reproduce, duplicate, copy, sell, resell or exploit any portion of the ApnoGarage, use of the ApnoGarage, or access to the ApnoGarage or any contact on the website through which the service is provided, without express written permission by us.`,
  },
  {
    title: "SECTION 3 – ACCURACY, COMPLETENESS AND TIMELINESS OF INFORMATION",
    body: `We are not responsible if information made available on this site is not accurate, complete or current. The material on this site is provided for general information only and should not be relied upon or used as the sole basis for making decisions without consulting primary, more accurate, more complete or more timely sources of information. Any reliance on the material on this site is at your own risk.

This site may contain certain historical information. Historical information, necessarily, is not current and is provided for your reference only. We reserve the right to modify the contents of this site at any time, but we have no obligation to update any information on our site.`,
  },
  {
    title: "SECTION 4 – MODIFICATIONS TO THE SERVICE AND PRICES",
    body: `Prices for our products are subject to change without notice.

We reserve the right at any time to modify or discontinue the Service (or any part or content thereof) without notice at any time.

We shall not be liable to you or to any third-party for any modification, price change, suspension or discontinuance of the Service.`,
  },
  {
    title: "SECTION 5 – PRODUCTS OR SERVICES",
    body: `Certain products or services may be available exclusively online through the website. These products or services may have limited quantities and are subject to return or exchange only according to our Return Policy.

We reserve the right, but are not obligated, to limit the sales of our products or Services to any person, geographic region or jurisdiction. We may exercise this right on a case-by-case basis. We reserve the right to limit the quantities of any products or services that we offer. All descriptions of products or product pricing are subject to change at any time without notice, at the sole discretion of us.

We do not warrant that the quality of any products, services, information, or other material purchased or obtained by you will meet your expectations, or that any errors in the Service will be corrected.`,
  },
  {
    title: "SECTION 6 – ACCURACY OF BILLING AND ACCOUNT INFORMATION",
    body: `We reserve the right to refuse any order you place with us. We may, in our sole discretion, limit or cancel quantities purchased per person, per company or per order.

You agree to provide current, complete and accurate purchase and account information for all purchases made at our website. You agree to promptly update your account and other information, including your email address and credit card numbers and expiration dates, so that we can complete your transactions and contact you as needed.`,
  },
  {
    title: "SECTION 7 – OPTIONAL TOOLS",
    body: `We may provide you with access to third-party tools over which we neither monitor nor have any control nor input.

You acknowledge and agree that we provide access to such tools "as is" and "as available" without any warranties, representations or conditions of any kind and without any endorsement. We shall have no liability whatsoever arising from or relating to your use of optional third-party tools.

Any use by you of optional tools offered through the site is entirely at your own risk and discretion and you should ensure that you are familiar with and approve of the terms on which tools are provided by the relevant third-party provider(s).`,
  },
  {
    title: "SECTION 8 – THIRD-PARTY LINKS",
    body: `Certain content, products and services available via our Service may include materials from third-parties.

Third-party links on this site may direct you to third-party websites that are not affiliated with us. We are not responsible for examining or evaluating the content or accuracy and we do not warrant and will not have any liability or responsibility for any third-party materials or websites, or for any other materials, products, or services of third-parties.

We are not liable for any harm or damages related to the purchase or use of goods, services, resources, content, or any other transactions made in connection with any third-party websites.`,
  },
  {
    title: "SECTION 9 – USER COMMENTS, FEEDBACK AND OTHER SUBMISSIONS",
    body: `If, at our request, you send certain specific submissions or without a request from us you send creative ideas, suggestions, proposals, plans, or other materials, whether online, by email, by postal mail, or otherwise (collectively, 'comments'), you agree that we may, at any time, without restriction, edit, copy, publish, distribute, translate and otherwise use in any medium any comments that you forward to us.

You agree that your comments will not violate any right of any third-party, including copyright, trademark, privacy, personality or other personal or proprietary right. You are solely responsible for any comments you make and their accuracy.`,
  },
  {
    title: "SECTION 10 – PERSONAL INFORMATION",
    body: `Your submission of personal information through the store is governed by our Privacy Policy.`,
  },
  {
    title: "SECTION 11 – ERRORS, INACCURACIES AND OMISSIONS",
    body: `Occasionally there may be information on our site or in the Service that contains typographical errors, inaccuracies or omissions that may relate to product descriptions, pricing, promotions, offers, product shipping charges, transit times and availability. We reserve the right to correct any errors, inaccuracies or omissions, and to change or update information or cancel orders if any information in the Service or on any related website is inaccurate at any time without prior notice.`,
  },
  {
    title: "SECTION 12 – PROHIBITED USES",
    body: `In addition to other prohibitions as set forth in the Terms of Service, you are prohibited from using the site or its content: (a) for any unlawful purpose; (b) to solicit others to perform or participate in any unlawful acts; (c) to violate any international, federal, provincial or state regulations, rules, laws, or local ordinances; (d) to infringe upon or violate our intellectual property rights or the intellectual property rights of others; (e) to harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate based on gender, sexual orientation, religion, ethnicity, race, age, national origin, or disability; (f) to submit false or misleading information; (g) to upload or transmit viruses or any other type of malicious code.

We reserve the right to terminate your use of the Service or any related website for violating any of the prohibited uses.`,
  },
  {
    title: "SECTION 13 – DISCLAIMER OF WARRANTIES; LIMITATION OF LIABILITY",
    body: `We do not guarantee, represent or warrant that your use of our service will be uninterrupted, timely, secure or error-free.

You expressly agree that your use of, or inability to use, the service is at your sole risk. The service and all products and services delivered to you through the service are (except as expressly stated by us) provided 'as is' and 'as available' for your use, without any representation, warranties or conditions of any kind.

In no case shall Albos Pvt Ltd, our directors, officers, employees, affiliates, agents, contractors, interns, suppliers, service providers or licensors be liable for any injury, loss, claim, or any direct, indirect, incidental, punitive, special, or consequential damages of any kind, including, without limitation lost profits, lost revenue, lost savings, loss of data, replacement costs, or any similar damages.`,
  },
  {
    title: "SECTION 14 – INDEMNIFICATION",
    body: `You agree to indemnify, defend and hold harmless Albos Pvt Ltd and our parent, subsidiaries, affiliates, partners, officers, directors, agents, contractors, licensors, service providers, subcontractors, suppliers, interns and employees, harmless from any claim or demand, including reasonable attorneys' fees, made by any third-party due to or arising out of your breach of these Terms of Service or the documents they incorporate by reference, or your violation of any law or the rights of a third-party.`,
  },
  {
    title: "SECTION 15 – SEVERABILITY",
    body: `In the event that any provision of these Terms of Service is determined to be unlawful, void or unenforceable, such provision shall nonetheless be enforceable to the fullest extent permitted by applicable law, and the unenforceable portion shall be deemed to be severed from these Terms of Service, such determination shall not affect the validity and enforceability of any other remaining provisions.`,
  },
  {
    title: "SECTION 16 – TERMINATION",
    body: `The obligations and liabilities of the parties incurred prior to the termination date shall survive the termination of this agreement for all purposes.

These Terms of Service are effective unless and until terminated by either you or us. You may terminate these Terms of Service at any time by notifying us that you no longer wish to use our Services, or when you cease using our site.

If in our sole judgment you fail, or we suspect that you have failed, to comply with any term or provision of these Terms of Service, we also may terminate this agreement at any time without notice.`,
  },
  {
    title: "SECTION 17 – ENTIRE AGREEMENT",
    body: `The failure of us to exercise or enforce any right or provision of these Terms of Service shall not constitute a waiver of such right or provision.

These Terms of Service and any policies or operating rules posted by us on this site or in respect to The Service constitutes the entire agreement and understanding between you and us and govern your use of the Service, superseding any prior or contemporaneous agreements, communications and proposals, whether oral or written, between you and us.`,
  },
  {
    title: "SECTION 18 – GOVERNING LAW",
    body: `These Terms of Service and any separate agreements whereby we provide you Services shall be governed by and construed in accordance with the laws of India and jurisdiction of Bangalore, Karnataka.`,
  },
  {
    title: "SECTION 19 – CHANGES TO TERMS OF SERVICE",
    body: `You can review the most current version of the Terms of Service at any time at this page.

We reserve the right, at our sole discretion, to update, change or replace any part of these Terms of Service by posting updates and changes to our website. It is your responsibility to check our website periodically for changes. Your continued use of or access to our website or the Service following the posting of any changes to these Terms of Service constitutes acceptance of those changes.`,
  },
  {
    title: "SECTION 20 – CONTACT INFORMATION",
    body: `Questions about the Terms of Service should be sent to us at support@albos.com.

Albos Pvt. Ltd.\nContact: Chandra Prakash\nEmail: albostechnologies016@gmail.com`,
  },
];

// ─── Screen ───────────────────────────────────────────────────────────────────
export default function TermsOfService({ navigation }) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.bgCard} />
      <TopNav
        title="Terms of Service"
        showBack
        onBackPress={() => navigation.goBack()}
        transparent={false}
      />

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Terms of Services</Text>
          <Text style={styles.headerMeta}>Albos Pvt. Ltd. · Last updated: 2025</Text>
        </View>

        {/* Sections */}
        {SECTIONS.map((sec, i) => (
          <View key={i} style={styles.section}>
            <Text style={styles.sectionTitle}>{sec.title}</Text>
            <Text style={styles.sectionBody}>{sec.body}</Text>
          </View>
        ))}

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>© 2025 Albos Pvt. Ltd. All rights reserved.</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },
  scroll: {
    paddingHorizontal: SIZES.md,
    paddingBottom: SIZES.xxl,
  },

  // Header
  header: {
    paddingVertical: SIZES.lg,
    paddingHorizontal: SIZES.xs,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
    marginBottom: SIZES.md,
  },
  headerTitle: {
    fontFamily: FONTS.bold,
    fontSize: 22,
    color: COLORS.textPrimary,
    letterSpacing: -0.3,
    marginBottom: 4,
  },
  headerMeta: {
    fontFamily: FONTS.regular,
    fontSize: SIZES.textSm ?? 13,
    color: COLORS.textMuted,
  },

  // Sections
  section: {
    marginBottom: SIZES.lg,
    backgroundColor: COLORS.bgCard,
    borderRadius: SIZES.radiusMd ?? 12,
    padding: SIZES.md,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
  },
  sectionTitle: {
    fontFamily: FONTS.bold,
    fontSize: SIZES.textSm ?? 13,
    color: COLORS.primary,
    letterSpacing: 0.4,
    textTransform: "uppercase",
    marginBottom: SIZES.sm,
  },
  sectionBody: {
    fontFamily: FONTS.regular,
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 22,
  },

  // Footer
  footer: {
    paddingTop: SIZES.md,
    alignItems: "center",
  },
  footerText: {
    fontFamily: FONTS.regular,
    fontSize: 12,
    color: COLORS.textMuted,
  },
});
